from gigachat import GigaChat
from gigachat.models import Chat, Messages, MessagesRole, Function, FunctionParameters
import requests
import json
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# 1. КЛЮЧИ
# ============================================================
GIGACHAT_KEY = os.getenv("GIGACHAT_CREDENTIALS")
YANDEX_API_KEY = os.getenv("YANDEX_API_KEY")
YANDEX_WEATHER_KEY = os.getenv("YANDEX_WEATHER_API_KEY")
GIS_API_KEY = os.getenv("GIS_API_KEY")
YANDEX_EMAIL = os.getenv("YANDEX_EMAIL")
YANDEX_EMAIL_PASSWORD = os.getenv("YANDEX_EMAIL_PASSWORD")

# ============================================================
# 2. ПОДКЛЮЧЕНИЕ К GigaChat
# ============================================================
giga = GigaChat(
    credentials=GIGACHAT_KEY,
    verify_ssl_certs=False,
    timeout=90,
)

# ============================================================
# 3. ПЕРЕМЕННЫЕ ДЛЯ ХРАНЕНИЯ ДАННЫХ ГОСТЕЙ
# ============================================================
pending_guests = []  # список email гостей, ожидающих приглашения
waiting_for_emails = False  # режим ожидания ввода email
last_event_info = {}  # информация о мероприятии

# ============================================================
# 4. ОПИСАНИЕ ФУНКЦИЙ ДЛЯ GigaChat
# ============================================================

venue_function = Function(
    name="search_venue",
    description="Найти ресторан, кафе или банкетный зал в указанном городе",
    parameters=FunctionParameters(
        type="object",
        properties={
            "query": {"type": "string", "description": "Что ищем: ресторан, кафе, банкетный зал"},
            "city": {"type": "string", "description": "Город поиска"}
        },
        required=["query", "city"],
    ),
)

weather_function = Function(
    name="check_weather",
    description="Получить текущую погоду в указанном городе",
    parameters=FunctionParameters(
        type="object",
        properties={"city": {"type": "string", "description": "Название города"}},
        required=["city"],
    ),
)

timeline_function = Function(
    name="generate_timeline",
    description="Составить расписание праздника по часам",
    parameters=FunctionParameters(
        type="object",
        properties={"event_type": {"type": "string", "description": "Тип мероприятия: пикник, ресторан, домашний"}},
        required=["event_type"],
    ),
)

# ============================================================
# 5. ФУНКЦИИ
# ============================================================

def search_venue(query: str, city: str) -> str:
    """Поиск мест через 2ГИС Suggest API"""
    if not GIS_API_KEY:
        return "❌ Не указан API-ключ 2ГИС"
    
    try:
        search_query = f"{query} {city}"
        url = "https://catalog.api.2gis.com/3.0/suggests"
        params = {
            "key": GIS_API_KEY,
            "q": search_query,
            "page_size": 15,
            "locale": "ru_RU"
        }
        
        response = requests.get(url, params=params, timeout=30)
        data = response.json()
        
        if data.get('meta', {}).get('code') != 200:
            return f"❌ Ошибка 2ГИС"
        
        items = data.get('result', {}).get('items', [])
        
        if not items:
            return f"❌ В городе {city} не найдено {query}"
        
        results = []
        for item in items[:10]:
            item_type = item.get('type', '')
            if item_type in ['branch', 'building']:
                name = item.get('name', 'Название не указано')
                address = item.get('address_name', 'Адрес не указан')
                results.append(f"  • {name} — {address}")
        
        if not results:
            for item in items[:5]:
                name = item.get('name', 'Название не указано')
                address = item.get('address_name', 'Адрес не указан')
                results.append(f"  • {name} — {address}")
        
        return f"✅ {query.title()} в городе {city}:\n" + "\n".join(results)
        
    except Exception as e:
        return f"❌ Ошибка: {str(e)}"

def check_weather(city: str) -> str:
    """Реальная погода через Яндекс.Погоду"""
    if not YANDEX_WEATHER_KEY:
        return "❌ Не указан API-ключ Яндекс.Погоды"
    
    if not YANDEX_API_KEY:
        return "❌ Для погоды нужен Яндекс.Геокодер"
    
    try:
        geo_url = "https://geocode-maps.yandex.ru/1.x/"
        geo_params = {
            "apikey": YANDEX_API_KEY,
            "geocode": city,
            "format": "json"
        }
        geo_response = requests.get(geo_url, params=geo_params, timeout=30)
        geo_data = geo_response.json()
        
        members = geo_data.get('response', {}).get('GeoObjectCollection', {}).get('featureMember', [])
        if not members:
            return f"❌ Город '{city}' не найден"
        
        pos = members[0]['GeoObject']['Point']['pos'].split()
        lon, lat = pos[0], pos[1]
        
        weather_url = "https://api.weather.yandex.ru/v2/forecast"
        headers = {"X-Yandex-API-Key": YANDEX_WEATHER_KEY}
        params = {
            "lat": lat,
            "lon": lon,
            "lang": "ru_RU",
            "limit": 1
        }
        
        weather_response = requests.get(weather_url, headers=headers, params=params, timeout=30)
        data = weather_response.json()
        
        if 'fact' not in data:
            return f"❌ Ошибка получения погоды"
        
        fact = data['fact']
        temp = fact['temp']
        feels_like = fact['feels_like']
        wind_speed = fact['wind_speed']
        
        return f"🌤️ Погода в {city}: {temp}°C (ощущается как {feels_like}°C), ветер {wind_speed} м/с"
        
    except Exception as e:
        return f"❌ Ошибка: {str(e)}"

def generate_timeline(event_type: str) -> str:
    """Расписание праздника"""
    templates = {
        "пикник": """📅 РАСПИСАНИЕ ПИКНИКА:
12:00 - Сбор и выезд
13:00 - Обустройство места
14:00 - Обед на природе
15:00 - Игры и конкурсы
17:00 - Чаепитие с тортом
18:00 - Сборы и отъезд""",
        "ресторан": """📅 РАСПИСАНИЕ В РЕСТОРАНЕ:
18:00 - Сбор гостей
18:30 - Аперитив
19:00 - Поздравления
19:30 - Горячее
21:00 - Торт и чай
22:00 - Музыка и танцы""",
        "домашний": """📅 РАСПИСАНИЕ ДОМАШНЕГО ПРАЗДНИКА:
15:00 - Подготовка
16:00 - Встреча гостей
16:30 - Фуршет
18:00 - Конкурсы
20:00 - Торт
21:00 - Просмотр фильма"""
    }
    result = templates.get(event_type.lower())
    if result:
        return result
    return f"📅 Доступные форматы: пикник, ресторан, домашний"

def send_invites(guest_emails, event_info):
    """Отправка приглашений гостям"""
    if not YANDEX_EMAIL or not YANDEX_EMAIL_PASSWORD:
        return "❌ Почта не настроена. Добавьте YANDEX_EMAIL в .env"
    
    results = []
    for email in guest_emails:
        try:
            msg = MIMEMultipart()
            msg['From'] = YANDEX_EMAIL
            msg['To'] = email
            msg['Subject'] = f"Приглашение на {event_info.get('event_type', 'праздник')}"
            
            body = f"""
Привет!

Тебя приглашают на {event_info.get('event_type', 'праздник')}.

📍 Место: {event_info.get('venue', 'уточняется')}
📅 Дата и время: {event_info.get('datetime', 'уточняется')}
🌤️ Погода: {event_info.get('weather', 'уточняется')}

Ждём тебя!
            """
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP('smtp.yandex.ru', 587)
            server.starttls()
            server.login(YANDEX_EMAIL, YANDEX_EMAIL_PASSWORD)
            server.send_message(msg)
            server.quit()
            
            results.append(f"✅ Приглашение отправлено на {email}")
        except Exception as e:
            results.append(f"❌ Ошибка отправки на {email}: {str(e)}")
    
    return "\n".join(results)

# ============================================================
# 6. ОСНОВНАЯ ФУНКЦИЯ АГЕНТА
# ============================================================

function_map = {
    "search_venue": search_venue,
    "check_weather": check_weather,
    "generate_timeline": generate_timeline,
}

def run_agent(user_message: str) -> str:
    global waiting_for_emails, pending_guests, last_event_info
    
    # Если ждём ввод email от пользователя
    if waiting_for_emails:
        # Пользователь вводит email через запятую
        emails = [e.strip() for e in user_message.split(',')]
        result = send_invites(emails, last_event_info)
        waiting_for_emails = False
        pending_guests = []
        last_event_info = {}
        return result
    
    # Обычная обработка запроса
    functions = [venue_function, weather_function, timeline_function]
    
    payload = Chat(
        messages=[Messages(role=MessagesRole.USER, content=user_message)],
        functions=functions,
        function_call="auto",
    )
    
    try:
        response = giga.chat(payload)
        message = response.choices[0].message
        finish_reason = response.choices[0].finish_reason
        
        if finish_reason == "function_call":
            function_name = message.function_call.name
            arguments = message.function_call.arguments
            
            if function_name in function_map:
                result = function_map[function_name](**arguments)
                # Сохраняем информацию для возможной рассылки
                if function_name == "search_venue":
                    last_event_info['venue'] = arguments.get('query', 'ресторан') + " в " + arguments.get('city', '')
                elif function_name == "check_weather":
                    last_event_info['weather'] = result
                return result
            else:
                return f"Неизвестная функция: {function_name}"
        else:
            answer = message.content
            # Проверяем, хочет ли пользователь отправить приглашения
            if "пригласить" in user_message.lower() or "отправить приглашение" in user_message.lower():
                # Извлекаем количество гостей или просто понимаем запрос
                waiting_for_emails = True
                last_event_info['event_type'] = "день рождения"
                return "📧 Отлично! Введите email-адреса гостей через запятую.\nПример: ivan@mail.ru, petr@yandex.ru, olga@gmail.com"
            return answer
    except Exception as e:
        return f"❌ Ошибка GigaChat: {str(e)}"

# ============================================================
# 7. ЗАПУСК
# ============================================================

if __name__ == "__main__":
    print("=" * 55)
    print("🤖 АВТОНОМНЫЙ ИИ-АГЕНТ (полная версия)")
    print("=" * 55)
    print("\n📋 Что я умею:")
    print("  🌤️  Погода в любом городе")
    print("  🍽️  Поиск ресторанов, кафе, банкетных залов")
    print("  📅  Составление расписания")
    print("  📧  Отправка приглашений гостям")
    print("\n📝 Примеры запросов:")
    print("  • Какая погода в Якутске?")
    print("  • Найди итальянский ресторан в Якутске")
    print("  • Составь расписание для пикника")
    print("  • Я хочу пригласить 5 человек")
    print("\n➡️  Напишите запрос (или 'выход')")
    print("-" * 55)
    
    while True:
        user_input = input("\n👤 Вы: ").strip()
        
        if user_input.lower() in ["выход", "quit", "exit", "q"]:
            print("\n🤖 Агент: До свидания! Хорошего праздника! 🎉")
            break
        
        if not user_input:
            continue
        
        print("\n⏳ Обрабатываю...")
        result = run_agent(user_input)
        print(f"\n🤖 Агент:\n{result}")